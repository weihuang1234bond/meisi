<?php
namespace app\model;

use think\Model;

class Novel extends Model {

}