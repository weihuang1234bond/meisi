<?php
/**
 * Api接口层
 * LastDate:    2017/11/27
 */

namespace app\controller;

use think\captcha\Captcha;
use phpmailer\SendEmail;
use think\Controller;
use think\Exception;
use think\Request;
use think\Db;
use systemPay\codePay;

use app\model\Order;


class Test extends Controller
{
    function index(){


    }
}


